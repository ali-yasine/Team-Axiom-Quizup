import 'package:flutter/material.dart';

class Player {
  final String username;
  Player({Key? key, required this.username});
}
